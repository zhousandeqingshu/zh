import shutil
import torch
import pandas as pd
import os
import numpy as np
import torch.nn as nn
from torch.utils.data import TensorDataset, Dataset, DataLoader, random_split
import argparse
from tqdm import tqdm
from .model import zh  # main model




def calculate_p(a):
    # 设定常量值
    Tmax = 143
    Tmin = 20
    result = []
    for row in a:
        a1 = row[0]
        a2 = row[1]

        if a1 <= 197:
            p1int = ((a1 + 2) // 3) + 19
            p1fra = a1 - p1int * 3 + 58
        else:
            p1int = a1 - 112
            p1fra = 0
        p1min = max(Tmin, p1int - 5)
        p1max = min(Tmax, p1min + 9)
        p1min = p1max - 9

        temp = ((a2 + 2) // 3) - 1
        p2int = temp + p1min
        p2fra = a2 - 2 - temp * 3

        result.append([p1int, p1fra, p2int, p2fra])
    return result


def save_best_model(net, optimizer, epoch, acc, dir):
    state = {
        'epoch': epoch,
        'acc': acc,
        'model_state_dict': net.state_dict(),
        'optimizer_state_dict': optimizer.state_dict()
    }

    if not os.path.exists(dir):
        os.mkdir(dir)
    else:
        shutil.rmtree(dir)
        os.mkdir(dir)

    filename = os.path.join(dir, 'model_best' + str(epoch + 1) + '.pth')
    torch.save(state, filename)


# def read_csv_file(file_path):
#     return pd.read_table(file_path, header=None, sep=' ').iloc[:, : 3].values


from multiprocessing import Pool, freeze_support

# def getFile(directory_path, sz=-1):
#     file_list = []
#     for root, dirs, files in os.walk(directory_path):
#         for file in files:
#             file_list.append(os.path.join(root, file))
#     if sz > 0:
#         file_list = file_list[:sz]
#     with Pool() as pool:
#         results = list(tqdm(pool.imap(read_csv_file, file_list), total=len(file_list)))
#
#     return results
#
# def split_v(v, split_len):
#     if split_len == 0:
#         return v
#     res = []
#     for _v in v:
#         _x = _v[:split_len]
#         res.append(_x)
#     return res

from concurrent.futures import ThreadPoolExecutor, as_completed  # 多线程

from concurrent.futures import ProcessPoolExecutor, as_completed  # 多进程


def getFile(directory_path, sz=-1):
    file_list = []
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_list.append(os.path.join(root, file))
    if sz > 0:
        file_list = file_list[:sz]

    res = []
    with ProcessPoolExecutor() as executor:
        futures = []
        for file_path in file_list:
            future = executor.submit(process_file, file_path)
            futures.append(future)

        for future in tqdm(as_completed(futures), total=len(futures), desc="Processing files", unit="file"):
            result = future.result()
            res.append(result)
    return res


def process_file(file_path):
    file = pd.read_table(file_path, header=None, sep=' ').values
    file_first_three_cols = file[:, :3]
    file_last_two_cols = file[:, 3:5]
    calculated_cols = calculate_p(file_last_two_cols)
    merged_file = np.concatenate((file_first_three_cols, calculated_cols), axis=1)
    return merged_file


def split_v(v, split_len):
    if split_len == 0:
        return v
    res = []
    for _v in v:
        _x = _v[:split_len]
        res.append(_x)
    return res


def create_batch(dataset, batch_size):
    return DataLoader(dataset, batch_size=batch_size, shuffle=True)

def evaluate_accuracy_gpu(net, data_iter, device=None):  # @save
    """使用GPU计算模型在数据集上的精度"""
    if isinstance(net, nn.Module):
        net.eval()  # 设置为评估模式
        if not device:
            device = next(iter(net.parameters())).device
    # 正确预测的数量，总预测的数量
    count_list = [0, 0]
    with torch.no_grad():
        for X, y in data_iter:
            X = X.to(device=device, dtype=torch.float)
            y = y.to(device=device, dtype=torch.float)
            y_hat = net(X)
            count_list[0] += calcACC(y_hat, y)
            count_list[1] += y.numel()
    return count_list[0] / count_list[1]


def calcACC(y_hat, y):
    return ((y_hat >= 0.5) == (y >= 0.5)).sum()


# @save
def train_ch6(net, train_iter, test_iter, valid_iter, num_epochs, lr, device, BestParameter):
    """用GPU训练模型(在第六章定义)"""

    def init_weights(m):
        if type(m) == nn.Linear or type(m) == nn.Conv2d or type(m) == nn.Conv3d:
            nn.init.xavier_uniform_(m.weight)

    net.apply(init_weights)

    net.to(device)

    optimizer = torch.optim.Adam(net.parameters(), lr=lr)

    loss = nn.BCELoss()
    train_l = 0
    train_acc = 0
    acc_ans = 0
    count_list = [0, 0, 0]

    loss_running = []
    best_accrary = []

    for epoch in range(num_epochs):
        # 训练损失之和，训练准确率之和，样本数
        net.train()
        for X, y in train_iter:
            X = X.to(device=device, dtype=torch.float)
            optimizer.zero_grad()
            y = y.to(device=device, dtype=torch.float)
            y_hat = net(X)
            l = loss(y_hat, y)
            l.backward()
            optimizer.step()
            with torch.no_grad():
                count_list[0] += l * X.shape[0]
                count_list[1] += calcACC(y_hat, y)
                count_list[2] += X.shape[0]
            train_l = count_list[0] / count_list[2]
            train_acc = count_list[1] / count_list[2]
            loss_running.append(train_l)

        import time
        # 在每轮训练后评估模型在测试数据集上的精度
        time_start = time.time()
        valid_acc = evaluate_accuracy_gpu(net, test_iter)
        if valid_acc > acc_ans:
            acc_ans = valid_acc
            test_acc = evaluate_accuracy_gpu(net, test_iter)
            best_accrary.append(round(test_acc.item() * 100, 2))
            print("目前存放了测试集的准确率最大值如下:", max(best_accrary))
        print(epoch + 1, "/", num_epochs, end=' ')
        print(f'loss {train_l:.3f}, train_acc {train_acc * 100:3f}, ans acc {acc_ans * 100:.3f}')
        print(f'{(time.time() - time_start) *1000} ms')
        print(
            f'loss {train_l:.3f}, train_acc {train_acc * 100:3f}, ans acc {acc_ans * 100:.3f},time_sample{ 1000* ((time.time() - time_start) / 6164000) } ms')
    print()
    # print(f'loss {train_l:.3f}, train_acc {train_acc * 100:3f}, ans acc {acc_ans * 100:.3f}')
    return loss_running

def main(SPEECH_LEN=0):
    parser = argparse.ArgumentParser(description='Command-line application')
    parser.add_argument('-c', required=False, help='Input carrier directory', default="H:\\New数据集\\feat\\CNV\\CN\\00")
    parser.add_argument('-s', required=False, help='Input steganography directory',
                        default="H:\\New数据集\\混合数据集\\READY\\PMS_CNV\\CN\\30")
    parser.add_argument('-t', type=int, help='Number of frames to extract', default=0)
    parser.add_argument('-d', type=int, help='The Dimension of data', default=3)
    parser.add_argument('-o', required=False, help='Save file')
    args = parser.parse_args()
    path_train_cover = os.path.join(args.c, "train")
    path_test_cover = os.path.join(args.c, "test")
    path_valid_cover = os.path.join(args.c, "valid")
    path_train_stego = os.path.join(args.s, "train")
    path_test_stego = os.path.join(args.s, "test")
    path_valid_stego = os.path.join(args.s, "valid")
    # 训练集
    train_cover_files = getFile(path_train_cover)
    train_stego_files = getFile(path_train_stego)
    # 测试集
    test_cover_files = getFile(path_test_cover)
    test_stego_files = getFile(path_test_stego)
    # 验证集
    valid_cover_files = getFile(path_valid_cover)
    valid_stego_files = getFile(path_valid_stego)
    SPEECH_LEN = SPEECH_LEN
    train_cf = split_v(train_cover_files, SPEECH_LEN)
    train_sf = split_v(train_stego_files, SPEECH_LEN)
    test_cf = split_v(test_cover_files, SPEECH_LEN)
    test_sf = split_v(test_stego_files, SPEECH_LEN)
    valid_cf = split_v(valid_cover_files, SPEECH_LEN)
    valid_sf = split_v(valid_stego_files, SPEECH_LEN)
    # 得到标签数据
    train_data = np.r_[train_cf, train_sf]
    train_label = np.r_[[[0]] * len(train_cf), [[1]] * len(train_sf)]
    test_data = np.r_[test_cf, test_sf]
    test_label = np.r_[[[0]] * len(test_cf), [[1]] * len(test_sf)]
    valid_data = np.r_[valid_cf, valid_sf]
    valid_label = np.r_[[[0]] * len(valid_cf), [[1]] * len(valid_sf)]
    train_data, train_label, test_data, test_label, valid_data, valid_label = map(torch.Tensor, (
    train_data, train_label, test_data, test_label, valid_data, valid_label))

    print('train_data' , train_data.shape)
    print('test_data',test_data.shape)
    print('valid_data',valid_data.shape)

    train_data_s = TensorDataset(train_data, train_label)
    test_data_s = TensorDataset(test_data, test_label)
    valid_data_s = TensorDataset(valid_data, valid_label)
    train_iter = create_batch(train_data_s, batch_size=256)
    test_iter = create_batch(test_data_s, batch_size=256)
    valid_iter = create_batch(valid_data_s, batch_size=256)

    print('training on', "cuda:0")
    Net = zh(input_size=7)
    # Net = zh()
    loss_running = train_ch6(Net, train_iter, test_iter, valid_iter, 100, 0.001, "cuda:0", BestParameter=None)

    return test_iter,valid_iter,train_iter,Net


'''
检测时间
'''
import time
def time_Consumption(valid_iter,net,Speech_Length):
    total_frames = sum(len(sample) for sample, _ in valid_iter.dataset)
    print('传入的迭代器中封装的个数: ' , len(valid_iter.dataset))
    print('总帧长total_frames' , total_frames)

    net.to("cuda:0")
    # 获取 test_iter 中的第一个批次数据
    first_batch = next(iter(test_iter))

    # 假设数据是 (X, y) 形式
    X, y = first_batch
    X = X.to(device="cuda:0", dtype=torch.float)
    y = y.to(device="cuda:0", dtype=torch.float)
    # 打印第一个批次数据的大小
    print(f'X size: {X.size()}, y size: {y.size()}')

    start = time.time()
    y_hat = net(X)
    end=time.time()
    print(f'耗时: { (end-start)*1000} ms')







# RNN-SM
class RNN_SM(nn.Module):
    def __init__(self , t):
        super(RNN_SM, self).__init__()
        self.lstm1 = nn.LSTM(input_size=7, hidden_size=50, batch_first=True)
        self.lstm2 = nn.LSTM(input_size=50, hidden_size=50, batch_first=True)
        self.flatten = nn.Flatten()
        self.dense = nn.Linear(in_features=500, out_features=1)
        self.activation = nn.Sigmoid()

    def forward(self, x):
        x, _ = self.lstm1(x)
        x, _ = self.lstm2(x)
        x = self.flatten(x)
        print(x.shape)
        x = self.dense(x)
        x = self.activation(x)
        return x
import time

def time_Consumption1(valid_iter, net, Speech_Length):
    total_frames = sum(len(sample) for sample, _ in valid_iter.dataset)
    print('传入的迭代器中封装的个数: ', len(valid_iter.dataset))
    print('总帧长total_frames: ', total_frames)


    # 获取 test_iter 中的第一个批次数据
    first_batch = next(iter(test_iter))
    # 假设数据是 (X, y) 形式
    X, y = first_batch
    # 打印一个批次数据的大小
    print(f'X size: {X.size()}, y size: {y.size()}')


    net.to("cuda:0")
    total_time = 0
    for batch in valid_iter:
        # Assume data is in (X, y) format
        X, y = batch
        X = X.to(device="cuda:0", dtype=torch.float)
        y = y.to(device="cuda:0", dtype=torch.float)

        start = time.time()
        y_hat = net(X)
        end = time.time()
        batch_time = (end - start) * 1000  # Time in milliseconds
        total_time += batch_time

        # Print the time for the current batch
        print(f'Batch time: {batch_time:.2f} ms')

    avg_time_per_frame = total_time / total_frames
    print(f'Total time: {total_time:.2f} ms')
    print(f'Average time per frame: {avg_time_per_frame:.2f} ms')


if __name__ == '__main__':
    torch.cuda.empty_cache()
    main()
    # test_iter, valid_iter, train_iter,Net = main(SPEECH_LEN=200)
    # time_Consumption1(valid_iter,Net,None)

    # print("=================================================")

