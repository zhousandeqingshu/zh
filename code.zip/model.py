import torch
import torch.nn as nn


# *********************************************************************************************************
class Feedforward(nn.Module):
    def __init__(self, input_size, emd_size, out_size):
        super(Feedforward, self).__init__()
        self.fc1 = nn.Linear(input_size, emd_size)  # 全连接层1，输入维度为input_size，输出维度为emd_size
        self.fc2 = nn.Linear(emd_size, out_size)  # 全连接层2，输入维度为emd_size，输出维度为out_size

        self.dropout = nn.Dropout(0.5)  # 添加一个dropout层用于数据增强

        if input_size != out_size:  # 如果输入维度和输出维度不相等，则需要添加一个线性层用于维度匹配
            self.shortcut = nn.Linear(input_size, out_size)
        else:
            self.shortcut = nn.Identity()  # 映射

    def forward(self, x):
        residual = x  # 保存输入的残差
        x = torch.relu(self.fc1(x))  # 使用ReLU激活函数
        x = self.dropout(x)  # 数据增强
        x = self.fc2(x)

        shortcut = self.shortcut(residual)  # 使用线性层进行维度匹配
        x += shortcut  # 将残差加到输出上
        x = torch.relu(x)  # 使用ReLU激活函数

        return x


class AttentionConvNet(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(AttentionConvNet, self).__init__()
        self.attention = nn.Linear(input_dim, input_dim)
        self.conv = nn.Conv1d(input_dim, output_dim, kernel_size=1)

    def forward(self, x):
        # 注意力机制
        attention_weights = torch.softmax(self.attention(x), dim=2)
        attended_x = x * attention_weights

        # 一维卷积
        output = self.conv(attended_x.permute(0, 2, 1))
        output = output.permute(0, 2, 1)

        return output


''''
CBAM模块
'''


class CBAMLayer(nn.Module):
    def __init__(self, channel, reduction=16, spatial_kernel=7):
        super(CBAMLayer, self).__init__()

        # channel attention 压缩H,W为1
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        # shared MLP
        self.mlp = nn.Sequential(
            # Conv2d比Linear方便操作
            # nn.Linear(channel, channel // reduction, bias=False)
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
            # inplace=True直接替换，节省内存
            nn.ReLU(inplace=True),
            # nn.Linear(channel // reduction, channel,bias=False)
            nn.Conv2d(channel // reduction, channel, 1, bias=False)
        )

        # spatial attention
        # self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
        #                       padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.mlp(self.max_pool(x))
        avg_out = self.mlp(self.avg_pool(x))
        channel_out = self.sigmoid(max_out + avg_out)
        x = channel_out * x
        #
        # max_out, _ = torch.max(x, dim=1, keepdim=True)
        # avg_out = torch.mean(x, dim=1, keepdim=True)
        # spatial_out = self.sigmoid(self.conv(torch.cat([max_out, avg_out], dim=1)))
        # x = spatial_out * x
        return x


class FeatureLearningNetwork(nn.Module):
    def __init__(self, input_size=3):
        super(FeatureLearningNetwork, self).__init__()
        self.lstm_Q = nn.LSTM(input_size, 50, 1)
        self.lstm_P = nn.LSTM(50, 50, 1)

        self.attetion = AttentionConvNet(input_size,100)

        # CBAM
        # self.attetion = CBAMLayer(1000)
        self.fc1 = nn.Linear(7, 100)

        self.fc = nn.Linear(100, 4)

        self.forwardLinear = Feedforward(input_size, 64, 100)

    def forward(self, x):
        # 为CBAM提供输入数据
        z = x.unsqueeze(0)
        # print('z',z.shape)

        z = torch.transpose(z, 1, 2)

        MQ, _ = self.lstm_Q(x)
        # print('MQ',MQ.shape) #(100,333,50)
        MP, _ = self.lstm_P(MQ)  # (100,333,50)
        # print('MP' ,MP.shape)
        M = torch.cat((MP, MQ), dim=2)  # (100,333,100# )
        t = self.forwardLinear(x)

        e = self.attetion(x)
        # e = self.fc1(e)
        # e = e.squeeze(0)
        # print('e',e.shape)
        # e = torch.transpose(e, 0, 1)

        t = self.forwardLinear(x)
        #
        # print('t',t.shape)
        # print('e',e.shape)
        # print('M',M.shape)

        M += e + t
        # print('M', M.shape)  #(100,333,4)
        M = self.fc(M)
        # print('M', M.shape)  #(100,333,4)
        return M


class ConvolutionalNetwork(nn.Module):
    def __init__(self):
        super(ConvolutionalNetwork, self).__init__()

        # 三层卷积层，保持输入通道数，输出通道数逐渐增加
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        # Batch Normalization层
        self.batch_norm = nn.BatchNorm1d(64)
        # 全连接层，将输出维度降为1
        self.fc = nn.Linear(64, 32)
        # ReLU激活函数
        self.relu = nn.ReLU()

    def forward(self, x):
        # 输入x的维度为（200, X, 4）
        x = x.permute(0, 2, 1)  # 将维度调整为（200, 4, X）以适应卷积层的输入要求
        print('x.shape',x.shape)
        # 通过三层卷积层
        x = self.relu(self.conv1(x))
        print('x1.shape', x.shape)
        x = self.relu(self.conv2(x))
        print('x2.shape', x.shape)
        x = self.relu(self.conv3(x))
        print('x3.shape', x.shape)

        # Batch Normalization
        x = self.batch_norm(x)
        # 池化操作，可根据实际需要选择不同的池化方法
        x = torch.mean(x, dim=2)  # 在最后一个维度上取平均，维度变为（200, 64）

        # 全连接层得到输出，维度变为（200, 1）
        x = self.fc(x)
        return x


class zh(nn.Module):
    def __init__(self, input_size=3):
        super(zh, self).__init__()
        self.FeatureLearningNetwork = FeatureLearningNetwork(input_size)
        self.slidNet = ConvolutionalNetwork()
        self.sigmod = nn.Sigmoid()

        self.linear = nn.Sequential(
            nn.Linear(32, 16),  nn.ReLU(), nn.Dropout(0.5),
            nn.Linear(16, 1), nn.Sigmoid()
        )

    def forward(self, x):
        out = self.FeatureLearningNetwork(x)
        out = self.slidNet(out)
        out = self.linear(out)
        return out


# *********************************************************************************************************