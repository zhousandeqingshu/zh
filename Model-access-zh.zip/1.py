import torch
import torch.nn.functional as F
from torch.autograd import Variable
import pandas as pd
import numpy as np
import torch.nn as nn
import os
from torch.utils.data import TensorDataset, Dataset, DataLoader, random_split
from torch.nn import functional as F
import argparse
from tqdm import tqdm

from contextlib import redirect_stdout

# from MYmodelTrainPMS.数据增强 import Feedforward # 导入前馈前连接网络
from .tool import Feedforward

def calculate_p(a):
    # 设定常量值
    Tmax = 143
    Tmin = 20
    result = []
    for row in a:
        a1 = row[0]
        a2 = row[1]

        if a1 <= 197:
            p1int = ((a1 + 2) // 3) + 19
            p1fra = a1 - p1int * 3 + 58
        else:
            p1int = a1 - 112
            p1fra = 0
        p1min = max(Tmin, p1int - 5)
        p1max = min(Tmax, p1min + 9)
        p1min = p1max - 9

        temp = ((a2 + 2) // 3) - 1
        p2int = temp + p1min
        p2fra = a2 - 2 - temp * 3

        result.append([p1int, p1fra, p2int, p2fra])
    return result

class SlideData(Dataset):
    def __init__(self, matrix1, matrix2, matrix3, matrix4, label):
        self.matrix1 = torch.tensor(matrix1)
        self.matrix2 = torch.tensor(matrix2)
        self.matrix3 = torch.tensor(matrix3)
        self.matrix4 = torch.tensor(matrix4)
        self.label = torch.tensor(label)

    def __len__(self):
        # 返回数据集的大小
        return len(self.matrix1)

    def __getitem__(self, idx):
        # 根据索引返回单个样本
        return self.matrix1[idx], self.matrix2[idx], self.matrix3[idx], self.matrix4[idx], self.label[idx]


def getFile(path):
    res = []
    file_list = os.listdir(path)
    for file_name in tqdm(file_list, desc="Processing files", unit="file"):
        file = pd.read_table(os.path.join(path, file_name) ,sep=' ',header=None).iloc[:, 3:5].values
        file = calculate_p(file)
        res.append(file)
    return res

def split_v(v, split_len):
    if split_len == 0:
        return v
    res = []
    for _v in v:
        _x = _v[:split_len]
        res.append(_x)
    return res


def create_batch(dataset, batch_size):
    return DataLoader(dataset, batch_size=batch_size, shuffle=True)

class AttentionConvNet(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(AttentionConvNet, self).__init__()
        self.attention = nn.Linear(input_dim, input_dim)
        self.conv = nn.Conv1d(input_dim, output_dim, kernel_size=1)

    def forward(self, x):
        # 注意力机制
        attention_weights = torch.softmax(self.attention(x), dim=2)
        attended_x = x * attention_weights

        # 一维卷积
        output = self.conv(attended_x.permute(0, 2, 1))
        output = output.permute(0, 2, 1)

        return output
class FeatureLearningNetwork(nn.Module):
    def __init__(self , input_size=3):
        super(FeatureLearningNetwork, self).__init__()

        self.lstm_Q = nn.LSTM(input_size, 50, 1 )
        self.lstm_P = nn.LSTM(50, 50, 1)
        self.attetion = AttentionConvNet(input_size,100)
        self.fc = nn.Linear(100, 4)

        # self.MultiheadAttention = MultiheadAttention(1000,4)
        self.forwardLinear = Feedforward(input_size,64,100)
    def forward(self, x):
        MQ, _ = self.lstm_Q(x)
        MP, _ = self.lstm_P(MQ)
        M = torch.cat((MP, MQ), dim=2)  #(100,333,100)
        e = self.attetion(x)
        t = self.forwardLinear(x)
        M = M+e+t
        M = self.fc(M)
        return M
class ConvolutionalNetwork(nn.Module):
    def __init__(self):
        super(ConvolutionalNetwork, self).__init__()

        # 三层卷积层，保持输入通道数，输出通道数逐渐增加
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        # Batch Normalization层
        self.batch_norm = nn.BatchNorm1d(64)
        # 全连接层，将输出维度降为1
        self.fc = nn.Linear(64, 32)
        # ReLU激活函数
        self.relu = nn.ReLU()
    def forward(self, x):
        # 输入x的维度为（200, X, 4）
        x = x.permute(0, 2, 1)  # 将维度调整为（200, 4, X）以适应卷积层的输入要求
        # 通过三层卷积层
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.relu(self.conv3(x))
        # Batch Normalization
        x = self.batch_norm(x)
        # 池化操作，可根据实际需要选择不同的池化方法
        x = torch.mean(x, dim=2)  # 在最后一个维度上取平均，维度变为（200, 64）
        # 全连接层得到输出，维度变为（200, 1）
        x = self.fc(x)
        return x

"""
通道注意力机制
"""
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction_ratio, in_channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _ = x.size()
        y = self.avg_pool(x).view(b, c)  # 平均池化后展平为（batch_size, channels）
        y = self.fc(y).view(b, c, 1)  # 通道注意力加权系数，维度为（batch_size, channels, 1）
        return x * y.expand_as(x)  # 通道注意力加权结果


class zh(nn.Module):
    def __init__(self,input_size=3):
        super(zh, self).__init__()
        self.FeatureLearningNetwork = FeatureLearningNetwork(input_size)
        self.slidNet = ConvolutionalNetwork()
        self.sigmod = nn.Sigmoid()

        self.linear = nn.Sequential(
            nn.Linear(32, 16), nn.BatchNorm1d(16), nn.ReLU(), nn.Dropout(0.5),
            nn.Linear(16, 1), nn.Sigmoid()
        )
    def forward(self, x):
        out = self.FeatureLearningNetwork(x)
        out = self.slidNet(out)
        out = self.linear(out)
        return out
def evaluate_accuracy_gpu(net, data_iter, device=None):  # @save
    """使用GPU计算模型在数据集上的精度"""
    if isinstance(net, nn.Module):
        net.eval()  # 设置为评估模式
        if not device:
            device = next(iter(net.parameters())).device
    # 正确预测的数量，总预测的数量
    count_list = [0, 0]
    with torch.no_grad():
        for X,y in data_iter:
            X = X.to(device=device, dtype=torch.float)
            y = y.to(device=device, dtype=torch.float)
            y_hat = net(X)
            count_list[0] += calcACC(y_hat, y)
            count_list[1] += y.numel()
    return count_list[0] / count_list[1]


def calcACC(y_hat, y):
    return ((y_hat >= 0.5) == (y >= 0.5)).sum()

# @save
def train_ch6(net, train_iter, test_iter, num_epochs, lr, device):
    """用GPU训练模型(在第六章定义)"""

    def init_weights(m):
        if type(m) == nn.Linear or type(m) == nn.Conv2d or type(m) == nn.Conv3d:
            nn.init.xavier_uniform_(m.weight)

    net.apply(init_weights)
    net.to(device)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    loss = nn.BCELoss()
    train_l = 0
    train_acc = 0
    acc_ans = 0
    count_list = [0, 0, 0]

    for epoch in range(num_epochs):
        # 训练损失之和，训练准确率之和，样本数
        net.train()
        for X,y in train_iter:
            X = X.to(device=device, dtype=torch.float)
            optimizer.zero_grad()
            y = y.to(device=device, dtype=torch.float)
            # print(net, frame_1.device, frame_3.device, frame_5.device, X.device, y.device)
            y_hat = net(X)
            l = loss(y_hat, y) + (net.linear[4].weight ** 2).sum() / 2
            l.backward()
            optimizer.step()
            with torch.no_grad():
                count_list[0] += l * X.shape[0]
                count_list[1] += calcACC(y_hat, y)
                count_list[2] += X.shape[0]
            train_l = count_list[0] / count_list[2]
            train_acc = count_list[1] / count_list[2]

        test_acc = evaluate_accuracy_gpu(net, test_iter)
        if test_acc > acc_ans:
            acc_ans = test_acc
        print(epoch + 1, "/", num_epochs, end=' ')
        print(f'loss {train_l:.3f}, train_acc {train_acc*100:3f}, ans acc {acc_ans*100:.3f}')
    print()
    print(f'loss {train_l:.3f}, train_acc {train_acc*100:3f}, ans acc {acc_ans*100:.3f}')

def main():

    parser = argparse.ArgumentParser(description='Command-line application')
    parser.add_argument('-c', required=True, help='Input carrier directory')
    parser.add_argument('-s', required=True, help='Input steganography directory')
    parser.add_argument('-t', type=int, help='Number of frames to extract', default=0)
    parser.add_argument('-d', type=int, help='The Dimension of data', default=3)
    parser.add_argument('-o', required=True, help='Save file')
    args = parser.parse_args()

    # argsc = "H:\\dataset\\CNV_divide\\0.0\\Chinese"
    # argss = "H:\\dataset\\CNV_divide\\0.1\\Chinese"
    # argsc = "H:\\dataset\\freq_HYF_divide\\0.0\\Chinese"
    # argss = "H:\\dataset\\freq_HYF_divide\\0.1\\Chinese"

    argsc = "H:\\New数据集\\feat\\PMS\\CN\\00"
    argss = "H:\\New数据集\\feat\\PMS\\CN\\02"

    # argsc = "H:\\New数据集\\feat\\CNV\\CN\\00"
    # argss = "H:\\New数据集\\feat\\CNV\\CN\\07"
    # argsc = "H:\\dataset\\NPP_divide\\0.0\\Chinese"
    # argss = "H:\\dataset\\NPP_divide\\0.1\\Chinese"
    path_train_cover = os.path.join(argsc, "train")
    path_test_cover = os.path.join(argsc, "test")
    path_train_stego = os.path.join(argss, "train")
    path_test_stego = os.path.join(argss, "test")
    train_cover_files = getFile(path_train_cover)
    train_stego_files = getFile(path_train_stego)
    test_cover_files = getFile(path_test_cover)
    test_stego_files = getFile(path_test_stego)
    SPEECH_LEN = 0
    train_cf = split_v(train_cover_files, SPEECH_LEN)
    train_sf = split_v(train_stego_files, SPEECH_LEN)
    test_cf = split_v(test_cover_files, SPEECH_LEN)
    test_sf = split_v(test_stego_files, SPEECH_LEN)
    train_data = np.r_[train_cf, train_sf]
    train_label = np.r_[[[0]] * len(train_cf), [[1]] * len(train_sf)]
    test_data = np.r_[test_cf, test_sf]
    test_label = np.r_[[[0]] * len(test_cf), [[1]] * len(test_sf)]
    # 打乱数据并保持对应关系
    indices = np.random.permutation(len(train_data))
    train_data = train_data[indices]
    train_label = train_label[indices]
    indices1 = np.random.permutation(len(test_data))
    test_data = test_data[indices1]
    test_label = test_label[indices1]
    train_data,train_label,test_data,test_label=map(torch.Tensor , (train_data,train_label,test_data,test_label))
    train_data_s = TensorDataset(train_data, train_label)
    test_data_s = TensorDataset(test_data, test_label)
    train_iter = create_batch(train_data_s, batch_size=256)
    test_iter = create_batch(test_data_s, batch_size=256)
    print('training on', "cuda:0")
    CSW = zh(input_size=4)
    train_ch6(CSW, train_iter, test_iter, 600, 0.001, "cuda:0")
    # result_root_path = os.path.join(opt.root_path, "HSFN_result")
    # if not os.path.exists(result_root_path):
    #     os.mkdir(result_root_path)
    # result_path_ = os.path.join(result_root_path, "%s_%s_%s_%sms" % (opt.language, opt.code, opt.algorithm, opt.time))
    # if not os.path.exists(result_path_):
    #     os.mkdir(result_path_)
    # result_path = os.path.join(result_path_, "HSFN")
    # if not os.path.exists(result_path):
    #     os.mkdir(result_path)
if __name__ == '__main__':
    torch.cuda.empty_cache()
    main()

