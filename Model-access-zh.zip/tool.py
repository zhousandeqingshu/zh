import argparse


from keras.models import Sequential
from keras.layers import Dense, Activation, LSTM, Flatten
import pandas as pd

import os
import torch.nn as nn
from tqdm import tqdm
import torch
import numpy as np

class Feedforward(nn.Module):
    def __init__(self, input_size, emd_size, out_size):
        super(Feedforward, self).__init__()
        self.fc1 = nn.Linear(input_size, emd_size)  # 全连接层1，输入维度为input_size，输出维度为emd_size
        self.fc2 = nn.Linear(emd_size, out_size)  # 全连接层2，输入维度为emd_size，输出维度为out_size

        self.dropout = nn.Dropout(0.5)  # 添加一个dropout层用于数据增强

        if input_size != out_size:  # 如果输入维度和输出维度不相等，则需要添加一个线性层用于维度匹配
            self.shortcut = nn.Linear(input_size, out_size)
        else:
            self.shortcut = nn.Identity()  #映射

    def forward(self, x):
        residual = x  # 保存输入的残差
        x = torch.relu(self.fc1(x))  # 使用ReLU激活函数
        x = self.dropout(x)  # 数据增强
        x = self.fc2(x)

        shortcut = self.shortcut(residual)  # 使用线性层进行维度匹配
        x += shortcut  # 将残差加到输出上
        x = torch.relu(x)  # 使用ReLU激活函数

        return x

